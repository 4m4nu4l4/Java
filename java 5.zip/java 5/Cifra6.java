public class Cifra6 {

    public String textoCifrado = " ";
    public String mensagem = " ";
    public int chave = 0;
    public String alfabeto = "abdcefghijklmnopqrstuvwxyz";

    public Cifra6(String mensagem, int chave) {
        this.mensagem = mensagem.toLowerCase(); //deixa em minúscula
        this.chave = chave;
    }
    
    public String cifrar() {
        for (int i = 0; i < this.mensagem.length(); i++){
            char letra = this.mensagem.charAt(i);
            int posicao = this.alfabeto.indexOf(letra);
            int novaPosicao = (posicao + this.chave);

        }
    }
}
