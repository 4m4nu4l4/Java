//import java.text.ParseException;
import java.text.SimpleDateFormat; //formatar data e hora em strings
import java.util.Date; //manipular datas e horas
import java.util.Scanner; //ler os dados

import java.util.ArrayList;

public class CriaPessoa { // esse cód representa a 2
    public static void main(String args) {
        ArrayList<Pessoa> pessoas = new ArrayList()<Pessoa>(); //era p conectar as coisa por meio desse cód >:(
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o nome da pessoa: ");
        String nome = scanner.nextLine();

        System.out.print("Digite o peso (em kg): ");
        double peso = scanner.nextDouble();

        System.out.print("Digite a altura (em metros): ");
        double altura = scanner.nextDouble();

        System.out.print("Digite a data de nascimento (no formato dd/MM/yyyy): ");
        String dataNascimentoStr = scanner.next();

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date dataNascimento = dateFormat.parse(dataNascimentoStr);

        Pessoa pessoa = new Pessoa(nome, peso, altura, dataNascimento);

        double imc = pessoa.calcularIMC();
        String classificacao = pessoa.classificarIMC();

        System.out.println("IMC: " + imc); //aqui lê o tipo de imc e puxa tmb a classificação da pessoa
        System.out.println("Classificação: " + classificacao);
        // Esse case 2 que o sor tinha feito na aula eu não entendi, não poderia fazer só assim puxando os dados do IMC E   da classificação?
    }
}
