import java.util.Scanner;

public class cifras {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a senha");
        String senha = sc.nextLine();

        System.out.println("Digite o valor constante");
        int constante = sc.nextInt();

        Cifra6 Cifra6 = new Crifa6(senha, constante);
        Crifa6.criptografar();
    }
}
