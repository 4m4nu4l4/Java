import java.util.Scanner;

public class Servidor { // Esse programa representa o 4
    int numero;
    int agencia;
    float saldo;
    String nomeDoCliente;

    public void Conta(int numero, int agencia, float saldo, String nomeDoCliente){
        this.numero = numero;
        this.agencia = agencia;
        this.saldo = saldo;
        this.nomeDoCliente = nomeDoCliente;
    }

    public void deposito(float valor){ /// ADICIONA NO SALDO
        this.saldo += valor;
    }

    public void saque(float valor){ // REMOVE DO SALDO
        this.saldo -= valor;
    }

    public float saldoTotal(){ // montante final :)
        return this.saldo;
    }
}