/*3) Crie uma classe que represente uma Conta Corrente, devendo ter as propriedades Número da Conta, Agência, Saldo, Nome do Titular e os métodos Depósito, Saque e Saldo Total. 
4) Crie um programa que receba a conta corrente e deposite e saque valores, ao final imprimindo o saldo existente*/

import java.util.Scanner;

public class Cliente { //Esse cód representa a 3
    public static void main(String[] args) {

        int opcao; //poderia ser void?
        float valor;

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o numero da conta");
        int numero = sc.nextInt();

        System.out.println("Digite sua agencia");
        int agencia = sc.nextInt();

        System.out.println("Digite seu saldo");
        float saldo = sc.nextFloat();

        sc.nextLine(); // Limpar o buffer
        System.out.println("Digite seu nome");

        String nomeDoCliente = sc.nextLine();
        Conta conta = new Conta(numero, agencia, saldo, nomeDoCliente); //instância que representa toda a conta bancária

        do {
            System.out.println("Escolha a ação:");
            System.out.println("1 - Deposito");
            System.out.println("2 - Saque");
            System.out.println("3 - Consultar Saldo");
            System.out.println("4 - Sair");
            opcao = sc.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("Digite o valor a ser depositado");
                    valor = sc.nextFloat();
                    conta.deposito(valor);
                    break;

                case 2:
                    System.out.println("Digite o valor a ser sacado");
                    valor = sc.nextFloat();
                    conta.saque(valor);
                    break;

                case 3:
                    System.out.println("Seu saldo é " + conta.saldoTotal());
                    break;
                    
                case 4:
                    System.out.println("Tchau");
                    break;
            }

        } while (opcao != 4);
    }
}
